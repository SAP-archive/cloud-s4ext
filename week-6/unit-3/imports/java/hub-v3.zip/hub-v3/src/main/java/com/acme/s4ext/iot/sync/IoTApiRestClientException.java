package com.acme.s4ext.iot.sync;

public class IoTApiRestClientException extends Exception {

	private static final long serialVersionUID = 1L;

	public IoTApiRestClientException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public IoTApiRestClientException(String arg0) {
		super(arg0);

	}

}
